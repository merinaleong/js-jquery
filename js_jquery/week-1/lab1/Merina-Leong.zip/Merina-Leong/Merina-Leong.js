/*
Merina Leong
A00988891
Lab 1
*/

function catSize(){
  var width = document.getElementById("cat").width;
  document.getElementById("bird").setAttribute("width", width);
}

function dogSize(){
  var width = document.getElementById("cat").width;
  document.getElementById("dog").setAttribute("width", width);
}
